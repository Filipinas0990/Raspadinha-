/* ============================================================
   CONFIGURAÇÕES SECRETAS
   ⚠️ NÃO COMMITAR NO GIT - ADICIONE AO .gitignore
   ============================================================ */
const CONFIG_SECRET = {
  // Número do WhatsApp da farmácia (só dígitos, com DDI 55 + DDD)
  whatsappNumero: "556492835266",

  // Mensagem que chega pronta no WhatsApp da farmácia
  whatsappMensagem: "Olá! Ganhei um prêmio na raspadinha e quero resgatar: ",

  // Senha para acessar o painel de admin (MUDE ISSO AGORA!)
  senhaAdmin: "admin123",
};
